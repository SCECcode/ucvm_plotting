#!/usr/bin/env python

import sys
import os

cmd="../ucvm_plotting/plot_cross_section.py -b 35.21,-121 -u 35.21,-118 -c cca -s 0 -e 5000 -v 100 -h 1000 -g 2.5 -a b -d vs -o cross_section_cca_bi.png"
print(cmd)
os.system(cmd)
