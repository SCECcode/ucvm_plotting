##
#  @file elevation_cross_section.py
#  @brief Plots a cross section to an image or a pre-existing plot.
#  @author 
#  @version 18.
#
#  Allows for generation of a elevation cross section between two points.

#  Imports
from .cvm_ucvm import Point, MaterialProperties, UCVM, UCVM_CVMS
from .cvm_plot import Plot, math, plot_cmapDiscretize, cm, mcolors, basemap, plt, np
from .cvm_common import VERSION

import random
import string

try:
    import pyproj
except Exception:
    print("ERROR: PyProj must be installed for this script to work.")
    exit(1)

##
#  @class ElevationCrossSection
#  @brief Plots a elevation cross section between two @link common.Point Points @endlink.
#
#  Generates a cross section that can either be saved as a file or displayed
#  to the user. 
class ElevationCrossSection:
    
    ##
    #  Initializes the elevation cross section class.
    #
    #  @param startingpoint The @link common.Point starting point @endlink from which this plot should start.
    #  @param endingpoint The @link common.Point ending point @endlink at which this plot will end.
    #  @param toelevaation The ending elevation, in meters, where this plot should end.
    #  @param hspacing The discretization interval in meters, horizontally.
    #  @param vspacing The discretization interval in meters, vertically.
    #  @param cvm The CVM from which to retrieve these material properties.
    def __init__(self, startingpoint, endingpoint, meta={}):

        self.meta=meta

        if not isinstance(startingpoint, Point):
            raise TypeError("The starting point must be an instance of Point.")
        else:
            ## Defines the @link common.Point starting point @endlink for the cross section.
            self.startingpoint = startingpoint
            
        if not isinstance(endingpoint, Point):
            raise TypeError("The ending point must be an instance of Point.")
        else:
            ## Defines the @link common.Point ending point @endlink for the cross section.
            self.endingpoint = endingpoint

        ## The discretization of the plot, in meters.
        if 'vertical_spacing' in self.meta :
            self.vspacing = float(self.meta['vertical_spacing'])
        else:
            self.vspacing = 0 

        if 'horizontal_spacing' in self.meta :
            self.hspacing = float(self.meta['horizontal_spacing'])
        else:
            self.hspacing = 0 

        if 'ending_elevation' in self.meta :
            self.toelevation = float(self.meta['ending_elevation'])
        else:
            self.toelevation = -15000  ## max, -15000

        if (self.toelevation - self.startingpoint.elevation) % self.vspacing != 0:
            raise ValueError("%s\n%s\n%s" % ("The spacing value does not divide evenly into the requested elevation. ", \
                          "Please make sure that the elevation (%.2f - %.2f) divided by the spacing " % (self.toelevation, startingpoint.elevation), \
                          "%.2f has no remainder" % (self.vspacing)))
        else:
            ## Defines the elevation to which the plot should go in meters.
            self.startelevation = self.startingpoint.elevation
            
        self.z_range = None
        if 'zrange1' in self.meta and 'zrange2' in self.meta :
            self.z_range=self.meta['zrange1']+","+self.meta['zrange2']

        self.floors = None
        if 'vsfloor' in self.meta and 'vpfloor' in self.meta and 'densityfloor' in self.meta :
            self.floors=self.meta['vsfloor']+","+self.meta['vpfloor']+","+self.meta['densityfloor']

        ## The CVM to use (must be installed with UCVM).
        if 'cvm' in self.meta :
            self.cvm = self.meta['cvm']
        else:
            self.cvm = None 

        if 'datafile' in self.meta :
            self.datafile = self.meta['datafile']
        else:
            self.datafile = None

        if 'outfile' in self.meta:
            self.filename = self.meta['outfile']
        else:
            self.filename = None

    ## 
    #  Generates the elevation profile in a format that is ready to plot.
    def getplotvals(self, mproperty='vs') :

        point_list = []
        lon_list = []
        lat_list = []
        elevation_list = []

        proj = pyproj.Proj(proj='utm', zone=11, ellps='WGS84')

        x1, y1 = proj(self.startingpoint.longitude, self.startingpoint.latitude)
        x2, y2 = proj(self.endingpoint.longitude, self.endingpoint.latitude)

        num_prof = int(math.sqrt((x2-x1)*(x2-x1) + \
                                 (y2-y1)*(y2-y1))/self.hspacing)
        
        jstart = self.startelevation

        toto=int(self.toelevation)
        if(toto <=0 ):
          toto = toto-1
        else:
          toto = toto+1

        for j in range(int(self.startelevation), toto, int(self.vspacing)):
            elevation_list.append( round(j,3))
            for i in range(0, num_prof + 1):
                x = x1 + i*(x2-x1)/float(num_prof)
                y = y1 + i*(y2-y1)/float(num_prof)
                lon, lat = proj(x, y, inverse=True)
                point_list.append(Point(lon, lat, elevation=j))
                if ( j == jstart) :
                  lon_list.append( round(lon,5))
                  lat_list.append( round(lat,5))
                
        self.lon_list=lon_list
        self.lat_list=lat_list
        self.elevation_list=elevation_list

        u = UCVM(install_dir=self.installdir, config_file=self.configfile, z_range=self.z_range, floors=self.floors)

### MEI -- TODO, need to have separate routine that generates cross section datafile
        if (self.datafile != None) :
            ## Private number of x points.
            self.num_x = num_prof +1
            ## Private number of y points.
            self.num_y =  math.ceil((self.toelevation - self.startelevation) / self.vspacing) +1

            print("\nUsing -->"+self.datafile)
##            print("expecting x "+str(self.num_x)+" y "+str(self.num_y))
            if self.datafile.rfind(".raw") != -1 :
                data = u.import_raw_data(self.datafile, self.num_x, self.num_y)
            else:
                data = u.import_np_float_array(self.datafile, self.num_x, self.num_y)

## this set of data is only for --datatype: either 'vs', 'vp', 'rho', or 'poisson'
        ## The 2D array of retrieved material properties.
            self.materialproperties = [[MaterialProperties(-1, -1, -1) for x in range(self.num_x)] for x in range(self.num_y)] 
            datapoints = data.reshape(self.num_y, self.num_x)

            for y in range(0, self.num_y):
                for x in range(0, self.num_x):   
                    tmp=datapoints[y][x]
                    if(mproperty == 'vp'):
                      self.materialproperties[y][x].setProperty('Vp',tmp)
                    if(mproperty == 'density'):
                      self.materialproperties[y][x].setProperty('Density',tmp)
                    if(mproperty == 'poisson'):
                      self.materialproperties[y][x].setProperty('Poisson',tmp)
                    if(mproperty == 'vs'):
                      self.materialproperties[y][x].setProperty('Vs',tmp)
        else:
            data = u.query(point_list, self.cvm, elevation=1)


            ## Private number of x points.
            self.num_x = num_prof + 1
            ## Private number of y points.
            self.num_y = math.ceil((self.toelevation - self.startelevation) / self.vspacing) + 1

        
        ## The 2D array of retrieved material properties.
            self.materialproperties = [[MaterialProperties(-1, -1, -1) for x in range(self.num_x)] for x in range(self.num_y)] 

        
            for y in range(0, self.num_y):
                for x in range(0, self.num_x):   
                    self.materialproperties[y][x] = data[y * self.num_x + x]     
#            print("outputting num_x "+str(self.num_x)+" num_y "+str(self.num_y))

    ## 
    #  Plots the horizontal slice either to an image or a file name.
    # 
    def plot(self) :

        self.installdir = None
        if 'installdir' in self.meta :
           self.installdir = self.meta['installdir']

        self.configfile = None
        if 'configfile' in self.meta :
           self.configfile = self.meta['configfile']

        if 'color' in self.meta :
           color_scale = self.meta['color']

        scale_gate = None
        if 'gate' in self.meta :
           scale_gate = float(self.meta['gate'])

        if color_scale == "b" and scale_gate is None:
           scale_gate=2.5
        
        if self.startingpoint.description == None:
            location_text = ""
        else:
            location_text = self.startingpoint.description + " "

        if 'data_type' in self.meta :
           mproperty = self.meta['data_type']
        else:
           mproperty = "vs"

        # Gets the better CVM description if it exists.
        try:
            cvmdesc = UCVM_CVMS[self.cvm]
        except: 
            cvmdesc = self.cvm

        if 'title' in self.meta :
            title = self.meta['title']
        else:
            title = "%s%s Elevation Cross Section from (%.2f, %.2f) to (%.2f, %.2f)" % (location_text, cvmdesc, self.startingpoint.longitude, \
                        self.startingpoint.latitude, self.endingpoint.longitude, self.endingpoint.latitude)
            self.meta['title']=title
            
        self.getplotvals(mproperty)
        
        # Call the plot object.
        p = Plot(None, None, None, None, 10, 10)

        plt.axes([0.1,0.7,0.8,0.25])
    
        # Figure out which is upper-right and bottom-left.
        ur_lat = self.startingpoint.latitude if self.startingpoint.latitude > self.endingpoint.latitude else self.endingpoint.latitude
        ur_lon = self.startingpoint.longitude if self.startingpoint.longitude > self.endingpoint.longitude else self.endingpoint.longitude
        ll_lat = self.startingpoint.latitude if self.startingpoint.latitude < self.endingpoint.latitude else self.endingpoint.latitude
        ll_lon = self.startingpoint.longitude if self.startingpoint.longitude < self.endingpoint.longitude else self.endingpoint.longitude
    
        # Add 1% to each for good measure.
        ur_lat = ur_lat + 0.03 * ur_lat
        ur_lon = ur_lon - 0.015 * ur_lon
        ll_lat = ll_lat - 0.03 * ll_lat
        ll_lon = ll_lon + 0.015 * ll_lon
    
        # Plot map up top.
        m = basemap.Basemap(projection='cyl', llcrnrlat=ll_lat, urcrnrlat=ur_lat, \
                            llcrnrlon=ll_lon, urcrnrlon=ur_lon, \
                            resolution='f', anchor='C')
    
        lat_ticks = np.arange(ll_lat, ur_lat + 0.1, (ur_lat - ll_lat))
        lon_ticks = np.arange(ll_lon, ur_lon + 0.1, (ur_lon - ll_lon))
    
        m.drawparallels(lat_ticks, linewidth=1.0, labels=[1,0,0,0])
        m.drawmeridians(lon_ticks, linewidth=1.0, labels=[0,0,0,1])
        m.drawstates()
        m.drawcountries()
    
        m.drawcoastlines()
        m.drawmapboundary(fill_color='aqua')
        m.fillcontinents(color='brown',lake_color='aqua')
    
        m.plot([self.startingpoint.longitude,self.endingpoint.longitude], [self.startingpoint.latitude,self.endingpoint.latitude])
    
        valign1 = "top"
        valign2 = "bottom"
        if self.endingpoint.latitude < self.startingpoint.latitude:
            valign1 = "bottom"
            valign2 = "top"
    
        plt.text(self.startingpoint.longitude, self.startingpoint.latitude, \
                 '[S] %.1f, %.1f' % (self.startingpoint.longitude, self.startingpoint.latitude), \
                 color='k', horizontalalignment="center", verticalalignment=valign1)
    
        plt.text(self.endingpoint.longitude, self.endingpoint.latitude, \
                 '[E] %.1f, %.1f' % (self.endingpoint.longitude, self.endingpoint.latitude), \
                 color='k', horizontalalignment="center", verticalalignment=valign2)
    
        plt.axes([0.05,0.18,0.9,0.54])
    
        datapoints = np.arange(self.num_x * self.num_y,dtype=np.float32).reshape(self.num_y, self.num_x)
            
        for y in range(0, self.num_y):
            for x in range(0, self.num_x):
                if self.datafile != None :
                    datapoints[y][x] = self.materialproperties[y][x].getProperty(mproperty)
                elif mproperty != "poisson" :
                    datapoints[y][x] = self.materialproperties[y][x].getProperty(mproperty)
                else:
                    datapoints[y][x] = u.poisson(self.materialproperties[y][x].getProperty("vs"), self.materialproperties[y][x].getProperty("vp"))    

        u = UCVM(install_dir=self.installdir, config_file=self.configfile)

        myInt=1000
        if mproperty == "poisson": ## no need to reduce.. should also be using sd or dd
           myInt=1
           if color_scale == "s" :
               color_scale = "sd"
           elif color_scale == "d" :
               color_scale = "dd"

        newdatapoints=datapoints/myInt

        self.max_val=np.nanmax(newdatapoints)
        self.min_val=np.nanmin(newdatapoints)
        self.mean_val=np.mean(newdatapoints)

#        print("max_val "+ str(self.max_val))
#        print("min_val "+ str(self.min_val))
#        print("mean_val"+ str(self.mean_val))

        BOUNDS = u.makebounds()
        TICKS = u.maketicks()

        if property == "vp":
            BOUNDS = [bound * 1.7 for bound in BOUNDS]
            TICKS = [tick * 1.7 for tick in TICKS]

        # Set default colormap and range
        colormap = basemap.cm.GMT_seis
        norm = mcolors.BoundaryNorm(BOUNDS, colormap.N)

        umax=round(self.max_val)
        if( umax < 5 ) :
            umax=5 

        if color_scale == "s":
            colormap = basemap.cm.GMT_seis
            norm = mcolors.Normalize(vmin=0,vmax=umax)
        elif color_scale == "s_r":
            colormap = basemap.cm.GMT_seis_r
            norm = mcolors.Normalize(vmin=0,vmax=umax)
        elif color_scale == "sd":
            BOUNDS= u.makebounds(self.min_val, self.max_val, 5, self.mean_val, substep=5)
#            colormap = basemap.cm.GMT_globe
            TICKS = u.maketicks(self.min_val, self.max_val, 5)
            norm = mcolors.Normalize(vmin=self.min_val,vmax=self.max_val)
        elif color_scale == "b":
            C = []
            for bound in BOUNDS :
               if bound < scale_gate :
                  C.append("grey")
               else:
                  C.append("red")
            colormap = mcolors.ListedColormap(C)
            norm = mcolors.BoundaryNorm(BOUNDS, colormap.N)
        elif color_scale == 'd':
            colormap = plot_cmapDiscretize(basemap.cm.GMT_seis, len(BOUNDS) - 1)
            norm = mcolors.BoundaryNorm(BOUNDS, colormap.N)  
        elif color_scale == 'd_r':
            colormap = plot_cmapDiscretize(basemap.cm.GMT_seis_r, len(BOUNDS) - 1)
            norm = mcolors.BoundaryNorm(BOUNDS, colormap.N)  
        elif color_scale == 'dd':
            BOUNDS= u.makebounds(self.min_val, self.max_val, 5, self.mean_val, substep=5, all=True)
            TICKS = u.maketicks(self.min_val, self.max_val, 5)
#            colormap = plot_cmapDiscretize(basemap.cm.GMT_globe, len(BOUNDS) - 1)
            colormap = plot_cmapDiscretize(basemap.cm.GMT_seis, len(BOUNDS) - 1)
            norm = mcolors.BoundaryNorm(BOUNDS, colormap.N)  
        else:
            print("ERROR: unknown option for colorscale.")


## MEI, TODO this is a temporary way to generate an output of a cross_section input file
        if( self.datafile == None ):
          self.meta['num_x'] = self.num_x
          self.meta['num_y'] = self.num_y
          self.meta['datapoints'] = datapoints.size
          self.meta['max'] = self.max_val.item()
          self.meta['min'] = self.min_val.item()
          self.meta['mean'] = self.mean_val.item()
          self.meta['lon_list'] = self.lon_list
          self.meta['lat_list'] = self.lat_list
          self.meta['elevation_list'] = self.elevation_list
          if self.filename:
              u.export_metadata(self.meta,self.filename)
              u.export_np_float_array(datapoints,self.filename)
          else:
#https://stackoverflow.com/questions/2257441/random-string-generation-with-upper-case-letters-and-digits-in-python
              rnd=''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(6))
              f = "cross_section"+rnd
              u.export_metadata(self.meta,f)
              u.export_np_float_array(datapoints,f)

        img = plt.imshow(newdatapoints, cmap=colormap, norm=norm)
        plt.xticks([0,self.num_x/2,self.num_x], ["[S] %.3f" % self.startingpoint.longitude, \
                                                 "%.3f" % ((float(self.endingpoint.longitude) + float(self.startingpoint.longitude)) / 2), \
                                                 "[E] %.3f" % self.endingpoint.longitude])
        plt.yticks([0,self.num_y/2,self.num_y], ["%.2f" % (self.startelevation/1000), \
                                                 "%.2f" % ((self.startelevation+ ((self.toelevation-self.startelevation)/2))/1000), \
                                                 "%.2f" % (self.toelevation / 1000)])
    
        plt.title(title)

        cax = plt.axes([0.1, 0.1, 0.8, 0.02])
        cbar = plt.colorbar(img, cax=cax, orientation='horizontal',ticks=TICKS,spacing='regular')
        if mproperty != "poisson":
            if(mproperty.title() == "Density") :
              cbar.set_label(mproperty.title() + " (g/cm^3)")
            else:
              cbar.set_label(mproperty.title() + " (km/s)")
        else:
            cbar.set_label("Poisson(Vs,Vp)")
       
        if self.filename:
            plt.savefig(self.filename)
        else:
            plt.show() 
