##
#  @file horizontal_slice.py
#  @brief Plots a horizontal slice either for display or saving to a file.
#  @author David Gill - SCEC <davidgil@usc.edu>
#  @version 14.7.0
#
#  Allows for generation of a horizontal slice, either interactively, via
#  arguments, or through Python code in the class HorizontalSlice.

#  Imports
from .cvm_ucvm import Point, MaterialProperties, UCVM, UCVM_CVMS
from .cvm_plot import Plot, math, plot_cmapDiscretize, cm, mcolors, basemap, plt, np
from .cvm_common import VERSION, pycvm_filestub

##
#  @class HorizontalSlice
#  @brief Plots a horizontal slice starting at a given @link common.Point Point @endlink
#         to another @link common.Point Point @endlink.
#
#  Generates a horizontal slice that can either be displayed to the user, saved to a file
#  or differenced with another plot.
class HorizontalSlice:
    
    ##
    #  Initializes the horizontal slice. The slice will go from the upper-left 
    #  @link common.Point Point @endlink parameter to the bottom-right 
    #  @link common.Point Point @endlink parameter, at the depth specified in the 
    #  upper-left point. 
    #
    #  @param upperleftpoint The @link common.Point starting point @endlink from which this plot should start.
    #  @param bottomrightpoint The @link common.Point ending point @endlink at which this plot should end.
    #  @param meta The metadata to hold configuration values
    #  
    def __init__(self, upperleftpoint, bottomrightpoint, meta={}) :
      
        self.meta = meta

        self.lons=[]
        self.lats=[]

        if 'nx' in self.meta :
            self.xsteps = self.meta['nx']
        else:
            self.xsteps = None

        if 'ny' in self.meta :
            self.ysteps = self.meta['ny']
        else:
            self.ysteps = None

        if 'datafile' in self.meta :
            self.datafile = self.meta['datafile']
        else:
            self.datafile = None

        if 'outfile' in self.meta:
            self.filename = self.meta['outfile']
        else:
            self.filename = None
        
        if not isinstance(upperleftpoint, Point):
            raise TypeError("Parameter upperleftpoint must be of type Point.")
        else:
            ## The upper-left point from which this plot should originate.
            self.upperleftpoint = upperleftpoint
            
        if not isinstance(bottomrightpoint, Point):
            raise TypeError("Parameter bottomrightpoint must be of type Point.")
        else:
            ## The bottom-right corner at which this plot should end.
            self.bottomrightpoint = bottomrightpoint
        
        #  Check that the bottom-right point is below and right of the upper-left point.
        if (self.upperleftpoint.longitude > self.bottomrightpoint.longitude) or \
           (self.upperleftpoint.latitude < self.bottomrightpoint.latitude):
            raise ValueError("The upper-left point must be higher than, and to the " + \
                             "left of, the bottom-right point.")

        if 'spacing' in self.meta:
            self.spacing = self.meta['spacing']
        #  Check the spacing. If it's specified in meters, convert to degrees.
        try:
            ## The spacing for the plot, defined in degrees. If meters specified, it's converted to degrees.
            self.spacing = float(self.spacing)
        except Exception:
            print("TODO")
        
        ## The community velocity model from which the data should be retrieved.
        if 'cvm' in self.meta:
            self.cvm = self.meta['cvm']
        else:
            self.cvm = None

        self.z_range = None
        if 'zrange1' in self.meta and 'zrange2' in self.meta :
            self.z_range=self.meta['zrange1']+","+self.meta['zrange2']

        self.floors = None
        if 'vsfloor' in self.meta and 'vpfloor' in self.meta and 'densityfloor' in self.meta :
            self.floors=self.meta['vsfloor']+","+self.meta['vpfloor']+","+self.meta['densityfloor']

        if 'scalemin' in self.meta and 'scalemax' in self.meta :
            ## user supplied a fixed scale bounds
            self.scalemin=float(self.meta['scalemin'])
            self.scalemax=float(self.meta['scalemax'])
        else:
            self.scalemin=None
            self.scalemax=None

        if 'installdir' in self.meta:
            self.installdir = self.meta['installdir']
        else:
            self.installdir = None

        if 'configfile' in self.meta:
            self.configfile = self.meta['configfile']
        else:
            self.configfile = None

        # Gets the better CVM description if it exists.
        try:
            cvmdesc = UCVM_CVMS[self.cvm]
        except:
            cvmdesc = self.cvm

        if self.upperleftpoint.description == None:
            location_text = ""
        else:
            location_text = self.upperleftpoint.description + " "

        if 'title' in self.meta :
            self.title =  self.meta['title']
        else:
            self.title = "%s%s Horizontal Slice at %.0fm" % (location_text, cvmdesc, self.upperleftpoint.depth)
            self.meta['title'] = self.title

        self.skip = None
        if ('skip' in self.meta) and (self.meta['skip'] == '1'):
           self.skip = True

        if 'data_type' in self.meta :
           self.mproperty = self.meta['data_type']
           if self.meta['data_type'] == 'all' :
               if self.skip == None:
                   self.mproperty = "vs"
        else:
           self.mproperty = "vs"

        self.ucvm = UCVM(install_dir=self.installdir, config_file=self.configfile, z_range=self.z_range, floors=self.floors)

    ##
    #  Retrieves the values for this horizontal slice and stores them in the class.
    def getplotvals(self, mproperty="vs"):
        
        #  How many y and x values will we need?
        
        ## The plot width - needs to be stored as property for the plot function to work.
        self.plot_width  = self.bottomrightpoint.longitude - self.upperleftpoint.longitude
        ## The plot height - needs to be stored as a property for the plot function to work.
        self.plot_height = self.upperleftpoint.latitude - self.bottomrightpoint.latitude 
        ## The number of x points we retrieved. Stored as a property for the plot function to work.
        if ( self.xsteps ) :
           self.num_x = int(self.xsteps)
        else :
           self.num_x = int(math.ceil(self.plot_width / self.spacing)) + 1

        ## The number of y points we retrieved. Stored as a property for the plot function to work.
        if ( self.ysteps ) :
           self.num_y = int(self.ysteps)
        else :
           self.num_y = int(math.ceil(self.plot_height / self.spacing)) + 1
        
        ## The 2D array of retrieved material properties.
        self.materialproperties = [[MaterialProperties(-1, -1, -1) for x in range(self.num_x)] for x in range(self.num_y)] 
        
        ucvm=self.ucvm

        if (self.datafile != None) :
            data=[]
            if self.datafile.rfind(".binary") != -1 :
                data = ucvm.import_binary(self.datafile, self.num_x, self.num_y)
            else :
                if self.datafile.rfind(".raw") != -1 :
                    data = ucvm.import_raw_data(self.datafile, self.num_x, self.num_y)
                else:  ## with .bin file
                    data2d = ucvm.import_np_float_array(self.datafile, self.num_x, self.num_y)
                ## flatten them
                    data1d = data2d.reshape([1, self.num_x * self.num_y])
                ## turn first one into a list
                    data=data1d[0].tolist()

            print("\nUsing --> "+self.datafile) 
        else: 
            #  Generate a list of points to pass to UCVM.
            ucvmpoints = []
            for y in range(0, self.num_y):
                for x in range(0, self.num_x):
                    lon = float('%.4f' % (self.upperleftpoint.longitude + x * self.spacing))
                    lat = float('%.4f' % (self.bottomrightpoint.latitude + y * self.spacing))
                    if(y == 0) :
                      self.lons.append(lon)
                    if(x == 0) :
                      self.lats.append(lat)
                    ucvmpoints.append(Point(lon, lat, self.upperleftpoint.depth))
            data = ucvm.query(ucvmpoints, self.cvm)

        i = 0
        j = 0
        isfloat = 0
#        fp=open("raw_data","w")
        if (self.datafile != None) :
            isfloat = 1
        for matprop in data:
            if isfloat:
                self.materialproperties[i][j].setProperty(mproperty,matprop)
#                float_string = "%.5f\n" % matprop
#                fp.write(float_string)
            else:
                self.materialproperties[i][j]=matprop
            j = j + 1
            if j >= self.num_x:
                j = 0
                i = i + 1
#        fp.close()

    ## 
    #  Plots the horizontal slice either to an image or a file name or both
    # 
    def plot(self, horizontal_label = None):

        if self.skip :
           if self.mproperty == "all" :
                self._file_all(horizontal_label)
           else:
                self._file(horizontal_label)
        else: 
            self._plot_file(horizontal_label) 

    ## 
    #  Plots the horizontal slice to an image and save a data file.
    # 
    def _plot_file(self, horizontal_label = None):

        color_scale = None
        if 'color' in self.meta :
           color_scale = self.meta['color']

        scale_gate = None
        if 'gate' in self.meta :
           scale_gate = float(self.meta['gate'])
        
        if color_scale == "b" and scale_gate is None:
           scale_gate=2.5

        mproperty = self.mproperty

        self.getplotvals(mproperty)

        # Call the plot object.
        p = Plot(False,self.title, "", "", None, 10, 10)

        ucvm = self.ucvm
#        UCVM(install_dir=self.installdir, config_file=self.configfile)

        m = basemap.Basemap(projection='cyl', llcrnrlat=self.bottomrightpoint.latitude, \
                            urcrnrlat=self.upperleftpoint.latitude, \
                            llcrnrlon=self.upperleftpoint.longitude, \
                            urcrnrlon=self.bottomrightpoint.longitude, \
                            resolution='f', anchor='C')
        
        lat_ticks = np.arange(self.bottomrightpoint.latitude, self.upperleftpoint.latitude + 0.1, self.plot_height / 2)
        lon_ticks = np.arange(self.upperleftpoint.longitude, self.bottomrightpoint.longitude + 0.1, self.plot_width / 2)
    
        m.drawparallels(lat_ticks, linewidth=1.0, labels=[1,0,0,0])
        m.drawmeridians(lon_ticks, linewidth=1.0, labels=[0,0,0,1])
        m.drawstates()
        m.drawcountries()
    
##        lons = np.linspace(self.upperleftpoint.longitude, self.bottomrightpoint.longitude - self.spacing, self.num_x-1)
##        lats = np.linspace(self.bottomrightpoint.latitude, self.upperleftpoint.latitude - self.spacing, self.num_y-1)
    
        # Get the properties.
        datapoints = np.arange(self.num_x * self.num_y,dtype=np.float32).reshape(self.num_y, self.num_x)

##        print("total cnt is %d"%(self.num_x * self.num_y))
        for i in range(0, self.num_y):
            for j in range(0, self.num_x):
                if mproperty != "poisson":
                    datapoints[i][j] = self.materialproperties[i][j].getProperty(mproperty)
                else :
                    datapoints[i][j] = ucvm.poisson(self.materialproperties[i][j].vs, self.materialproperties[i][j].vp) 

        myInt=1000
        if mproperty == "poisson": ## no need to reduce.. should also be using sd or dd
           myInt=1
           if color_scale == "s" :
               color_scale = "sd"
           elif color_scale == "d" :
               color_scale = "dd"

        newdatapoints=datapoints/myInt 

        newmax_val=np.nanmax(newdatapoints)
        newmin_val=np.nanmin(newdatapoints)
        newmean_val=np.nanmean(newdatapoints)

        self.max_val=np.nanmax(datapoints)
        self.min_val=np.nanmin(datapoints)
        self.mean_val=np.nanmean(datapoints)

        if self.scalemin != None and self.scalemax != None:
            BOUNDS= ucvm.makebounds(float(self.scalemin), float(self.scalemax), 5)
            TICKS = ucvm.aketicks(float(self.scalemin), float(self.scalemax), 5)
            umax=round(self.scalemax)
            umin=round(self.scalemin)
            umean=round((umax+umin)/2) 
        else:
            ## default BOUNDS are from 0 to 5
            BOUNDS = ucvm.makebounds()
            TICKS = ucvm.maketicks()
            umax=round(newmax_val)
            umin=round(newmin_val)
            umean=round(newmean_val)

##   s, s_r   0,5 / scalemin,scalemax
##   sd       umin,umax
##   b        0,5 / scalemin,scalemax
##   d, d_r   0,5 / scalemin,scalemax
##   dd       umin,umax

        if color_scale == "s":
            colormap = basemap.cm.GMT_seis
            norm = mcolors.Normalize(vmin=BOUNDS[0],vmax=BOUNDS[len(BOUNDS) - 1])
        elif color_scale == "s_r":
            colormap = basemap.cm.GMT_seis_r
            norm = mcolors.Normalize(vmin=BOUNDS[0],vmax=BOUNDS[len(BOUNDS) - 1])
        elif color_scale == "sd":
            colormap = basemap.cm.GMT_seis
            BOUNDS= ucvm.makebounds(umin, umax, 5, umean, substep=5)
            TICKS = ucvm.maketicks(umin, umax, 5)
            norm = mcolors.Normalize(vmin=BOUNDS[0],vmax=BOUNDS[len(BOUNDS) - 1])
        elif color_scale == "b":
            C = []
            for bound in BOUNDS :
               if bound < scale_gate :
                  C.append("grey")
               else:
                  C.append("red")
            colormap = mcolors.ListedColormap(C)
            norm = mcolors.BoundaryNorm(BOUNDS, colormap.N)

        elif color_scale == 'd':
            colormap = plot_cmapDiscretize(basemap.cm.GMT_seis, len(BOUNDS) - 1)
            norm = mcolors.BoundaryNorm(BOUNDS, colormap.N)
        elif color_scale == 'd_r':
            colormap = plot_cmapDiscretize(basemap.cm.GMT_seis_r, len(BOUNDS) - 1)
            norm = mcolors.BoundaryNorm(BOUNDS, colormap.N)
        elif color_scale == 'dd':
            BOUNDS= ucvm.makebounds(umin, umax, 5, umean, substep=5)
            TICKS = ucvm.maketicks(umin, umax, 5)
            colormap = plot_cmapDiscretize(basemap.cm.GMT_seis, len(BOUNDS) - 1)
            norm = mcolors.BoundaryNorm(BOUNDS, colormap.N)
        else:
            print("ERROR: unknown option for colorscale.")


# very special case for showing 'difference plot'
        if 'difference' in self.meta :
            bwr = plt.get_cmap('bwr')
            colormap = plot_cmapDiscretize(bwr, len(BOUNDS) - 1)
##            colormap = plot_cmapDiscretize(basemap.cm.GMT_globe, len(BOUNDS) - 1)
             

        if( self.datafile == None ):
          self.meta['num_x'] = self.num_x
          self.meta['num_y'] = self.num_y
          self.meta['datapoints'] = datapoints.size
          self.meta['max'] = self.max_val.item()
          self.meta['min'] = self.min_val.item()
          self.meta['mean'] = self.mean_val.item()
          ### slons and lats are off by one from earlier composition for drawing within edges, 
          ### so need to add in the last lon2 and lat2
          self.meta['lon_list']=self.lons
#          self.meta['lon_list'].append(float(self.meta['lon2']))
          self.meta['lat_list']=self.lats
#          self.meta['lat_list'].append(float(self.meta['lat2']))
          if self.filename:
              ucvm.export_metadata(self.meta,self.filename)
              ucvm.export_np_float_array(datapoints,self.filename)
                    

        ## reduce the datapoints before passing in..
        lons = np.linspace(self.upperleftpoint.longitude, self.bottomrightpoint.longitude - self.spacing, self.num_x-1)
        lats = np.linspace(self.bottomrightpoint.latitude, self.upperleftpoint.latitude - self.spacing, self.num_y-1)

#        t = m.transform_scalar(newdatapoints, self.lons, self.lats, len(self.lons), len(self.lats))
        t = m.transform_scalar(newdatapoints, lons, lats, len(lons), len(lats))
        img = m.imshow(t, cmap=colormap, norm=norm)

       
#        print("MIN is "+str(np.nanmin(datapoints)))
#        print("MAX is "+str(np.nanmax(datapoints)))
#        img=m.scatter(xlist, ylist, c=dlist, cmap=colormap, norm=norm, s=1, edgecolor='',marker='o')      
#        img=m.scatter(xcoords, ycoords, c=datapoints, cmap=colormap, norm=norm, s=1, edgecolor='',marker='o')      
    
        m.drawcoastlines()
    
        cax = plt.axes([0.125, 0.05, 0.775, 0.02])
        cbar = plt.colorbar(img, cax=cax, orientation='horizontal',spacing='proportional',ticks=TICKS)
        if mproperty != "poisson":
            if horizontal_label == None:
                if(mproperty.title() == "Density") :
                  cbar.set_label(mproperty.title() + " (g/cm^3)")
                else: 
                  if 'difference' in self.meta :
                    cbar.set_label(mproperty.title() + " (km)")
                  else:
                    cbar.set_label(mproperty.title() + " (km/s)")
            else:
                cbar.set_label(horizontal_label)
        else:
            cbar.set_label("Poisson(Vs,Vp)")
            
        if self.filename:
            plt.savefig(self.filename)
## MEI, TODO p.savehtml("show.html")
        else:
            plt.show()

    ## 
    #  Create the horizontal slice data file only
    # 
    def _file(self, horizontal_label = None):

        mproperty = self.mproperty

        self.getplotvals(mproperty)

        # Get the properties.
        datapoints = np.arange(self.num_x * self.num_y,dtype=np.float32).reshape(self.num_y, self.num_x)

##        print("total cnt is %d"%(self.num_x * self.num_y))
        for i in range(0, self.num_y):
            for j in range(0, self.num_x):
                if mproperty != "poisson":
                    datapoints[i][j] = self.materialproperties[i][j].getProperty(mproperty)
                else :
                    datapoints[i][j] = ucvm.poisson(self.materialproperties[i][j].vs, self.materialproperties[i][j].vp) 

        self.max_val= np.nanmax(datapoints)
        self.min_val=np.nanmin(datapoints)
        self.mean_val=np.mean(datapoints)

        ucvm = self.ucvm 

        if( self.datafile == None ):
          self.meta['num_x'] = self.num_x
          self.meta['num_y'] = self.num_y
          self.meta['datapoints'] = datapoints.size
          self.meta['max'] = self.max_val.item()
          self.meta['min'] = self.min_val.item()
          self.meta['mean'] = self.mean_val.item()
          self.meta['lon_list']=self.lons
          self.meta['lat_list']=self.lats
          if self.filename:
              ucvm.export_metadata(self.meta,self.filename)
              ucvm.export_np_float_array(datapoints,self.filename)
          else:
              #https://stackoverflow.com/questions/2257441/random-string-generation-with-upper-case-letters-and-digits-in-python
              rnd=''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(6))
              f = "horizontal_slice"+rnd
              ucvm.export_metadata(self.meta,f)
              ucvm.export_np_float_array(datapoints,f)


    ## 
    #  Create the horizontal slice data file only and one of each of vs, vp, density
    # 
    def _file_all(self, horizontal_label = None):

        self.datafile = None

        self.getplotvals()

        #label_uid_something.png
        if self.filename != None:
            fstub=pycvm_filestub(self.filename)
        else:
            rnd=''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(6))
            fstub = "horizontal_slice_"+rnd

        # Get the properties.
        datapoints = np.arange(self.num_x * self.num_y,dtype=np.float32).reshape(self.num_y, self.num_x)
        for mproperty in ['vs', 'vp', 'density' ] :

          self.meta['data_type']=mproperty
          # process for label + UID
          f = fstub+"_"+mproperty

          for i in range(0, self.num_y):
            for j in range(0, self.num_x):
                datapoints[i][j] = self.materialproperties[i][j].getProperty(mproperty)

          self.max_val= np.nanmax(datapoints)
          self.min_val=np.nanmin(datapoints)
          self.mean_val=np.mean(datapoints)

          ucvm = self.ucvm 

          self.meta['num_x'] = self.num_x
          self.meta['num_y'] = self.num_y
          self.meta['datapoints'] = datapoints.size
          self.meta['max'] = self.max_val.item()
          self.meta['min'] = self.min_val.item()
          self.meta['mean'] = self.mean_val.item()
          self.meta['lon_list']=self.lons
          self.meta['lat_list']=self.lats

          ucvm.export_metadata(self.meta,f+"_meta.json")
          ucvm.export_np_float_array(datapoints,f+"_data.bin")

